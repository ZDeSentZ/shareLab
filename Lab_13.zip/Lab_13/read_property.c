#define _CRT_SECURE_NO_WARNINGS
#include "all_func.h"
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <locale.h>

void read_property(student* STUD1, student temp, int n)
{
	setlocale(LC_ALL, "ru");
	int value, rating;
	FILE* bin;
	int p = 0;

	if ((bin = fopen("binary.dat", "rb")) == NULL)
	{
		printf("%s", strerror(errno));
		exit(0);
	}
	if (fread(&value, sizeof(int), 1, bin) != 1)
	{
		printf("%s", strerror(errno));
		exit(0);
	}
	printf("----Вывод записей по требуемому свойству----\n");
  	printf("Введите число (от 1 до 5) для показа записей с данной оценкой \n");
	scanf("%d", &rating);
	for (int i = 0; i < value; i++)
	{
		if (fread(&temp, sizeof(student), 1, bin) != 1)
		{
			printf("%s", strerror(errno));
			exit(0);
		}
		bool flag = false;
		for (int k = 0; k < 5; k++) if (temp.SES[k] == rating) flag = true;
		if (flag)
		{
			printf("%s\t %s\t ", temp.NAME, temp.GROUP);
			for (int j = 0; j < 5; j++) {
				printf("%f ", temp.SES[j]);
			}
			printf("\n");
			p++;
		}
	}
	if (p == 0) printf("Записей, удоволетворяющих введенному свойству, нет!\n");
	fclose(bin);
}