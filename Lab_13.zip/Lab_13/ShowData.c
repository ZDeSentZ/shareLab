#define _CRT_SECURE_NO_WARNINGS
#include "all_func.h"
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <locale.h>

//Вывод записей на экран
void ShowData(student* STUD1, int N)
{
	setlocale(LC_ALL, "ru");
	for (int i = 0; i < N; i++) {
		printf("%s\t %s\t ", STUD1[i].NAME, STUD1[i].GROUP);
		for (int j = 0; j < 5; j++)
		{
			printf("%f ", STUD1[i].SES[j]);
		}
		printf("\n");
	}
}