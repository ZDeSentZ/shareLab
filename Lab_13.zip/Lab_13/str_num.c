#define _CRT_SECURE_NO_WARNINGS
#include "all_func.h"
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <locale.h>

//считывание количества структур
int str_num() {
	setlocale(LC_ALL, "ru");
	int n;
	FILE* fp;
	if ((fp = fopen("structures.txt", "r")) == NULL)
	{
		printf("%s", strerror(errno));
		exit(0);
	}
	fscanf(fp, "%d", &n);
	fclose(fp);
	return n;
}