#define _CRT_SECURE_NO_WARNINGS
#include "all_func.h"
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <locale.h>

//Заполнение структур
void input(student* STUD1, int N)
{
	setlocale(LC_ALL, "ru");
	FILE* fp;
	if ((fp = fopen("structures.txt", "r")) == NULL)
	{
		printf("%s", strerror(errno));
		exit(0);
	}
	fseek(fp, sizeof(int), SEEK_SET);
	for (int i = 0; i < N; i++) fscanf(fp, "%30s %10s %f %f %f %f %f", STUD1[i].NAME, STUD1[i].GROUP, &STUD1[i].SES[0], &STUD1[i].SES[1], &STUD1[i].SES[2], &STUD1[i].SES[3], &STUD1[i].SES[4]);
	printf("\n----Считывание данных прошло успешно----\n\n");

}