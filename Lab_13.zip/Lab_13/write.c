#define _CRT_SECURE_NO_WARNINGS
#include "all_func.h"
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <locale.h>

//Запись данных в бинарный файл
void write(student* STUD1, int n)
{
	setlocale(LC_ALL, "ru");
	FILE* bin;
	if ((bin = fopen("binary.dat", "wb")) == NULL)
	{
		printf("%s", strerror(errno));
		exit(0);
	}
	if (fwrite(&n, sizeof(int), 1, bin) != 1)
	{
		printf("%s", strerror(errno));
		exit(0);
	}
	for (int i = 0; i < n; i++) if (fwrite(&STUD1[i], sizeof(student), 1, bin) != 1)
	{
		printf("%s", strerror(errno));
		exit(0);
	}
	fclose(bin);
	printf("\n----Запись в бинарный файл завершена----\n");
}