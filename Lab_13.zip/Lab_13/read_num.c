#define _CRT_SECURE_NO_WARNINGS
#include "all_func.h"
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <locale.h>

void read_num(student* STUD1, student temp, int n)
{
	setlocale(LC_ALL, "ru");
	int value, num;
	FILE* bin;
	int p = 0;

	if ((bin = fopen("binary.dat", "rb")) == NULL)
	{
		printf("%s", strerror(errno));
		exit(0);
	}
	if (fread(&value, sizeof(int), 1, bin) != 1)
	{
		printf("%s", strerror(errno));
		exit(0);
	}
	printf("Введите номер записи: ");
	scanf("%d", &num);
	if (num > value) printf("Такой записи не существует.");
	for (int i = 0; i < value; i++)
	{
		if (fread(&temp, sizeof(student), 1, bin) != 1)
		{
			printf("%s", strerror(errno));
			exit(0);
		}
		if (i + 1 == num)
		{
			printf("----Вывод запрашиваемой записи----\n");
			printf("%s\t %s\t ", temp.NAME, temp.GROUP);
			for (int j = 0; j < 5; j++) {
				printf("%f ", temp.SES[j]);
			}
			printf("\n");
		}
	}
	fclose(bin);
}
