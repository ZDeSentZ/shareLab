#define _CRT_SECURE_NO_WARNINGS
#ifndef all_func
#define all_func

typedef struct student {
	char NAME[30];
	char GROUP[10];
	float SES[5];
}student;

int str_num();
void input(student* STUD1, int n);
void sort(student* STUD1, int n);
void ShowData(student* STUD1, int n);
void write(student* STUD1, int n);
void read_property(student* STUD1, student temp, int n);
void read_num(student* STUD1, student temp, int n);

#endif