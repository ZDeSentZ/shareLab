#define _CRT_SECURE_NO_WARNINGS
#include "all_func.h"
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <locale.h>


int main() {
	setlocale(LC_ALL, "ru");
	int n = str_num();
	student STUD1[10], temp = { 0,0,0 };


	input(STUD1, n);
	sort(STUD1, n);
	ShowData(STUD1, n);
	write(STUD1, n);
	read_property(STUD1, temp, n);
	read_num(STUD1, temp, n);
	return 0;
}