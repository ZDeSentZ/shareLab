#define _CRT_SECURE_NO_WARNINGS
#include "all_func.h"
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <locale.h>

//Сортировка по возрастанию среднего балла
void sort(student* STUD1, int n)
{
	setlocale(LC_ALL, "ru");

	for (int i = 1; i < n; i++)
		for (int j = 0; j < n - i; j++)
		{
			float sr_znach_bef = 0;
			float sr_znach_aft = 0;

			for (int k = 0; k < 5; k++) {
				sr_znach_bef += STUD1[j].SES[k];
				sr_znach_aft += STUD1[j + 1].SES[k];
				k++;
			}
			if (sr_znach_bef > sr_znach_aft)
			{
				student temp = STUD1[j];
				STUD1[j] = STUD1[j + 1];
				STUD1[j + 1] = temp;
			}
		}
	printf("----Cортировка по возрастанию среднего балла завершена----\n\n");
}